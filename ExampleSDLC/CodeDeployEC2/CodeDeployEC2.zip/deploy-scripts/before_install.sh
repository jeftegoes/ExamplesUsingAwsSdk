rm -rf /var/www/*
rm -rf /etc/systemd/system/webapi.service
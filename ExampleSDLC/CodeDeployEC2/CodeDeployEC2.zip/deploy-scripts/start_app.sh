systemctl stop webapi.service
systemctl start webapi.service